package com.tedu.springboot2303;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot2303Application {

    public static void main(String[] args) {
        SpringApplication.run(SpringBoot2303Application.class, args);
    }

}
