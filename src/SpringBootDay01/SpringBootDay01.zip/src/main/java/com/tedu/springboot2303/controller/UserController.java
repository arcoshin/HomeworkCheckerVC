package com.tedu.springboot2303.controller;

import com.tedu.springboot2303.entity.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

/**
 * UserController用於處理所有與用戶有關的請求
 */
@Controller//SpringBoot框架中必須使用的註解，用以識別屬於控制器
public class UserController {
    private static File userDir;//用以存放所有用戶訊息的目錄

    static {
        /**
         * 靜態代碼塊只執行一次，節省資源
         */
        userDir = new File("./users");
        if (!userDir.exists()) {//目錄不存在時才創建
            userDir.mkdirs();
        }
    }

    @RequestMapping("/regUser")//SpringBoot框架中必須使用的註解，用以識別"調用被註記方法的條件"
    public void reg(HttpServletRequest request, HttpServletResponse response) {
        /**
         * 獲取瀏覽器表單中提交的數據
         */
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String nickname = request.getParameter("nickname");
        String ageString = request.getParameter("age");
        int age = Integer.parseInt(ageString);

        System.out.println("name = " + username + ",pwd = " + password + ",nick = " + nickname + ",age = " + ageString);

        /**
         * 必要簡易驗證
         */
        if (username == null || username.trim().isEmpty()||
            password == null || password.trim().isEmpty()||
            nickname == null || nickname.trim().isEmpty()||
            ageString == null || ageString.trim().isEmpty()||
            !ageString.matches("[0-9]+")
        )
        {
            try {
                response.sendRedirect("/reg_info_error.html");
            } catch (IOException e) {
                e.printStackTrace();
            }
            return;
        }

        /**
         * 保存這段數據
         */
        User user = new User(username, password, nickname, age);

        /**
         * 綁定地址，利用File另外一個構造器表達位址
         * new File(File file1,StringFile2name)
         * 可以綁定file1所在相同目錄中，名為file2的文件
         */
        File file = new File(userDir, username + ".obj");
        /**
         * 重複資料驗證
         */
        if (file.exists()) {//文件名已存在代表重複註冊
            try {
                response.sendRedirect("/reg_info_already_exist.html");
                return;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try (
                ObjectOutputStream oos = new ObjectOutputStream(
                        new BufferedOutputStream(
                                new FileOutputStream(file)
                        )
                );

        ) {
            oos.writeObject(user);

            /**
             * 發送一個結果給用戶(sendRedirect:重定向)
             */
            response.sendRedirect("/reg_success.html");
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
